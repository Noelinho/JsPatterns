// Player y game van a poder publicar eventos
makePublisher(Player.prototype);
makePublisher(game);

// Suscripción de venetos de Player
Player.prototype.on("newplayer", "addPlayer", game);
Player.prototype.on("play",      "handlePlay", game);

// Suscripción de venetos de Game
game.on("scorechange", scoreboard.update, scoreboard);

window.onkeypress = game.handleKeypress;

new Player('Jugador1',  '1');
new Player('Jugador2',  '0');