// player constructor
function Player(name) {
    this.points = 0;
    this.name = name;
}

// play method
Player.prototype.play = function () {
    this.points += 1;
    mediator.played();
};
