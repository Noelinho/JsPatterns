// go!
mediator.setup();
window.onkeypress = mediator.keypress;

function start(e)
{
    mediator.start(this);
}