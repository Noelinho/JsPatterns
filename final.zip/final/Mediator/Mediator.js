var mediator = {

    // all the players
    players: {},
    started: false,

    //
    setup: function () {
        var players = this.players;
        players.home = new Player('Home');
        players.guest = new Player('Guest');
        this.started = false;
    },

    // someone plays, update the score
    played: function () {
        var players = this.players,
            score = {
                Player1:  players.home.points,
                Player2: players.guest.points
            };

        scoreboard.update(score);
    },

    // handle user interactions
    keypress: function (e) {
        if (!mediator.started) {
            return false;
        }
        e = e || window.event; // IE
        if (e.which === 49) { // key "1"
            mediator.players.home.play();
            return;
        }
        if (e.which === 48) { // key "0"
            mediator.players.guest.play();
            return;
        }
    },

    start: function(e) {
        this.started = true;
        // game over in 30 seconds
        setTimeout(function () {
            window.onkeypress = null;
            alert('Game over!');
        }, 20000);
    }
};